namespace App.Models.Enums
{
    public enum Classification
    {
        Bronze = 1,
        Silver = 2,
        Gold = 3
    }
}